"""UK VAT reference data shared by the data generator and the rules engine.

This is a deliberately simplified subset of UK VAT rules so the project stays
readable. Always check current HMRC guidance before relying on any rate or
rule for real work.
"""
from __future__ import annotations

from dataclasses import dataclass

# Weights used by the modulus-97 check on a 9-digit UK VAT registration number.
WEIGHTS = (8, 7, 6, 5, 4, 3, 2)

RATES = {"standard": 0.20, "reduced": 0.05, "zero": 0.0, "exempt": 0.0}


@dataclass(frozen=True)
class Category:
    name: str
    treatment: str                  # standard | reduced | zero | exempt
    directions: tuple[str, ...]     # "purchase" and/or "sale"
    input_tax_recoverable: bool = True
    drc_eligible: bool = False      # may fall under the domestic reverse charge
    description: str = ""

    @property
    def rate(self) -> float:
        return RATES[self.treatment]


_CATEGORY_LIST = [
    # Purchases
    Category("office_supplies", "standard", ("purchase",), description="Stationery and office consumables"),
    Category("software_subscription", "standard", ("purchase",), description="SaaS subscription"),
    Category("professional_fees", "standard", ("purchase",), description="Legal and accounting fees"),
    Category("telecoms", "standard", ("purchase",), description="Business phone and broadband"),
    Category("marketing", "standard", ("purchase",), description="Advertising and design services"),
    Category("equipment", "standard", ("purchase",), description="Laptops and small equipment"),
    Category("insurance", "exempt", ("purchase",), description="Business insurance premium"),
    Category("bank_charges", "exempt", ("purchase",), description="Bank fees and charges"),
    Category("client_entertainment", "standard", ("purchase",), input_tax_recoverable=False,
             description="Entertaining clients (input VAT is blocked)"),
    Category("construction_services", "standard", ("purchase",), drc_eligible=True,
             description="Building works (domestic reverse charge may apply)"),
    # Purchases and sales
    Category("printed_books", "zero", ("purchase", "sale"), description="Printed books and manuals"),
    # Sales
    Category("consulting_services", "standard", ("sale",), description="Consulting fees"),
    Category("software_licences", "standard", ("sale",), description="Software licence income"),
    Category("childrens_clothing", "zero", ("sale",), description="Children's clothing"),
    Category("childrens_car_seats", "reduced", ("sale",), description="Children's car seats"),
]

CATEGORIES: dict[str, Category] = {c.name: c for c in _CATEGORY_LIST}


def vat_number_is_valid(vat_no: str | None) -> bool:
    """Check the format and modulus-97 checksum of a 9-digit UK VAT number.

    Validates structure only. It cannot tell you whether a number is
    registered; that needs a lookup against HMRC's VAT number checking service.
    """
    if not vat_no:
        return False
    s = str(vat_no).replace(" ", "").upper()
    if s.startswith("GB"):
        s = s[2:]
    if len(s) != 9 or not s.isdigit():
        return False
    total = sum(int(d) * w for d, w in zip(s[:7], WEIGHTS))
    check = int(s[7:])
    return (total + check) % 97 == 0 or (total + check + 55) % 97 == 0
