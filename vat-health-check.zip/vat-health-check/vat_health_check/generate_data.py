"""Generate a synthetic UK VAT ledger with known, labelled errors.

Why synthetic? Real VAT ledgers are confidential. A generated ledger lets us
(1) share the project publicly and (2) measure how well the checker performs,
because we know exactly which errors were injected.

Outputs (written to --out):
    ledger.csv        what a checker would see (no labels)
    ground_truth.csv  which transactions are wrong, and why (used for evaluation only)

Usage:
    python -m vat_health_check.generate_data --rows 2000 --error-rate 0.08 --seed 42
"""
from __future__ import annotations

import argparse
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from faker import Faker

from .reference import CATEGORIES, WEIGHTS, vat_number_is_valid

ERROR_TYPES = (
    "wrong_rate",
    "invalid_vat_number",
    "blocked_input_tax",
    "duplicate_invoice",
    "arithmetic_error",
    "reverse_charge_misuse",
)

# Log-normal (mu, sigma) for net amounts in GBP, per category.
AMOUNT_PARAMS = {
    "office_supplies": (5.0, 0.8), "software_subscription": (5.5, 0.7),
    "professional_fees": (7.0, 0.7), "telecoms": (5.0, 0.5),
    "marketing": (6.5, 0.8), "equipment": (6.8, 0.8),
    "insurance": (6.0, 0.7), "bank_charges": (3.5, 0.6),
    "client_entertainment": (5.0, 0.7), "construction_services": (8.2, 0.7),
    "printed_books": (3.5, 0.6), "consulting_services": (7.8, 0.7),
    "software_licences": (7.0, 0.8), "childrens_clothing": (4.5, 0.6),
    "childrens_car_seats": (4.7, 0.4),
}


def make_vat_number(rng: np.random.Generator) -> str:
    """Return a checksum-valid UK-style VAT number (randomly generated).

    Generated numbers may coincidentally match a real registration.
    """
    digits = rng.integers(0, 10, size=7)
    total = int(sum(int(d) * w for d, w in zip(digits, WEIGHTS)))
    check = (97 - total % 97) % 97
    return f"GB{''.join(str(int(d)) for d in digits)}{check:02d}"


def _corrupt_vat_number(rng: np.random.Generator, vat_no: str) -> str:
    """Change one digit so the checksum fails."""
    while True:
        pos = int(rng.integers(2, len(vat_no)))
        new = str((int(vat_no[pos]) + int(rng.integers(1, 10))) % 10)
        candidate = vat_no[:pos] + new + vat_no[pos + 1:]
        if not vat_number_is_valid(candidate):
            return candidate


def _make_parties(rng, fake):
    registered = [{"name": fake.company(), "vat_no": make_vat_number(rng)} for _ in range(60)]
    unregistered = [{"name": fake.company(), "vat_no": None} for _ in range(15)]
    customers = [{"name": fake.company(),
                  "vat_no": make_vat_number(rng) if rng.random() < 0.8 else None}
                 for _ in range(40)]
    return registered, unregistered, customers


def _pick(rng, items):
    return items[int(rng.integers(len(items)))]


def _clean_ledger(rng, fake, n_rows: int, start: date, days: int) -> pd.DataFrame:
    registered, unregistered, customers = _make_parties(rng, fake)
    purchase_cats = [c for c in CATEGORIES.values() if "purchase" in c.directions]
    sale_cats = [c for c in CATEGORIES.values() if "sale" in c.directions]
    seen_invoice_keys: set[tuple[str, str]] = set()
    rows = []

    for i in range(n_rows):
        direction = "purchase" if rng.random() < 0.7 else "sale"
        cat = _pick(rng, purchase_cats if direction == "purchase" else sale_cats)
        drc_applies = False

        if direction == "sale":
            party = _pick(rng, customers)
            rate = cat.rate
        elif cat.treatment == "exempt":
            party = _pick(rng, unregistered)           # insurers and banks charge no VAT
            rate = 0.0
        elif cat.treatment == "standard" and not cat.drc_eligible and rng.random() < 0.08:
            party = _pick(rng, unregistered)           # small supplier below the VAT threshold
            rate = 0.0
        else:
            party = _pick(rng, registered)
            drc_applies = cat.drc_eligible and rng.random() < 0.6
            rate = 0.0 if drc_applies else cat.rate

        mu, sigma = AMOUNT_PARAMS[cat.name]
        net = round(float(rng.lognormal(mu, sigma)), 2)
        vat = round(net * rate, 2)
        claimed = direction == "purchase" and vat > 0 and cat.input_tax_recoverable

        initials = "".join(w[0] for w in party["name"].split()[:3]).upper()
        while True:
            inv_no = f"{initials}-{int(rng.integers(10000, 99999))}"
            if (party["name"], inv_no) not in seen_invoice_keys:
                seen_invoice_keys.add((party["name"], inv_no))
                break

        inv_date = start + timedelta(days=int(rng.integers(0, days)))
        rows.append({
            "txn_id": f"TXN-{i + 1:06d}",
            "invoice_no": inv_no,
            "invoice_date": inv_date,
            "posting_date": inv_date + timedelta(days=int(rng.integers(0, 4))),
            "direction": direction,
            "counterparty": party["name"],
            "counterparty_vat_no": party["vat_no"],
            "category": cat.name,
            "description": cat.description,
            "net_amount": net,
            "vat_rate_applied": rate,
            "vat_amount": vat,
            "gross_amount": round(net + vat, 2),
            "drc_applies": drc_applies,
            "input_vat_claimed": claimed,
        })
    return pd.DataFrame(rows)


def _recompute(df: pd.DataFrame, idx: int, rate: float) -> None:
    net = df.at[idx, "net_amount"]
    cat = CATEGORIES[df.at[idx, "category"]]
    vat = round(net * rate, 2)
    df.at[idx, "vat_rate_applied"] = rate
    df.at[idx, "vat_amount"] = vat
    df.at[idx, "gross_amount"] = round(net + vat, 2)
    df.at[idx, "input_vat_claimed"] = (
        df.at[idx, "direction"] == "purchase" and vat > 0 and cat.input_tax_recoverable
    )


def _inject_errors(rng, df: pd.DataFrame, error_rate: float):
    df = df.copy()
    per_type = int(round(len(df) * error_rate)) // len(ERROR_TYPES)
    used: set[int] = set()
    labels: list[dict] = []
    duplicates: list[dict] = []

    rate_cats = [n for n, c in CATEGORIES.items()
                 if c.treatment in ("standard", "zero", "reduced") and n != "client_entertainment"]
    masks = {
        "wrong_rate": (df.category.isin(rate_cats) & ~df.drc_applies
                       & ((df.direction == "sale") | df.counterparty_vat_no.notna())),
        "invalid_vat_number": ((df.direction == "purchase") & (df.vat_amount > 0)
                               & df.counterparty_vat_no.notna() & df.input_vat_claimed),
        "blocked_input_tax": ((df.category == "client_entertainment") & (df.vat_amount > 0)),
        "duplicate_invoice": ((df.direction == "purchase") & (df.vat_amount > 0) & df.input_vat_claimed),
        "arithmetic_error": (df.vat_amount > 0),
        "reverse_charge_misuse": ((df.category == "construction_services") & df.drc_applies),
    }

    def draw(kind: str) -> list[int]:
        pool = [i for i in df.index[masks[kind]] if i not in used]
        take = min(per_type, len(pool))
        chosen = [int(i) for i in rng.choice(pool, size=take, replace=False)] if take else []
        used.update(chosen)
        return chosen

    for i in draw("wrong_rate"):
        correct = CATEGORIES[df.at[i, "category"]].rate
        new_rate = float(rng.choice([r for r in (0.20, 0.05, 0.0) if r != correct]))
        old_vat = df.at[i, "vat_amount"]
        _recompute(df, i, new_rate)
        labels.append({"txn_id": df.at[i, "txn_id"], "error_type": "wrong_rate",
                       "error_detail": f"Charged {new_rate:.0%}; correct rate is {correct:.0%}",
                       "vat_at_risk": abs(round(df.at[i, "vat_amount"] - old_vat, 2))})

    for i in draw("invalid_vat_number"):
        if rng.random() < 0.5:
            df.at[i, "counterparty_vat_no"] = None
            detail = "VAT claimed with no supplier VAT number"
        else:
            df.at[i, "counterparty_vat_no"] = _corrupt_vat_number(rng, df.at[i, "counterparty_vat_no"])
            detail = "Supplier VAT number fails checksum"
        labels.append({"txn_id": df.at[i, "txn_id"], "error_type": "invalid_vat_number",
                       "error_detail": detail, "vat_at_risk": df.at[i, "vat_amount"]})

    for i in draw("blocked_input_tax"):
        df.at[i, "input_vat_claimed"] = True
        labels.append({"txn_id": df.at[i, "txn_id"], "error_type": "blocked_input_tax",
                       "error_detail": "Input VAT claimed on client entertainment",
                       "vat_at_risk": df.at[i, "vat_amount"]})

    for i in draw("arithmetic_error"):
        delta = round(float(rng.uniform(1, 200)) * float(rng.choice([-1, 1])), 2)
        if rng.random() < 0.5:
            df.at[i, "gross_amount"] = round(df.at[i, "gross_amount"] + delta, 2)
            detail = "Gross does not equal net + VAT"
        else:
            df.at[i, "vat_amount"] = round(df.at[i, "vat_amount"] + delta, 2)
            df.at[i, "gross_amount"] = round(df.at[i, "net_amount"] + df.at[i, "vat_amount"], 2)
            detail = "VAT amount does not equal net x rate"
        labels.append({"txn_id": df.at[i, "txn_id"], "error_type": "arithmetic_error",
                       "error_detail": detail, "vat_at_risk": abs(delta)})

    for i in draw("reverse_charge_misuse"):
        _recompute(df, i, 0.20)
        labels.append({"txn_id": df.at[i, "txn_id"], "error_type": "reverse_charge_misuse",
                       "error_detail": "VAT charged and claimed where the domestic reverse charge applies",
                       "vat_at_risk": df.at[i, "vat_amount"]})

    next_id = len(df) + 1
    for i in draw("duplicate_invoice"):
        dup = df.loc[i].to_dict()
        dup["txn_id"] = f"TXN-{next_id:06d}"
        next_id += 1
        dup["posting_date"] = dup["posting_date"] + timedelta(days=int(rng.integers(5, 30)))
        if rng.random() < 0.3:                      # same invoice re-keyed in a different format
            dup["invoice_no"] = dup["invoice_no"].replace("-", "")
        duplicates.append(dup)
        labels.append({"txn_id": dup["txn_id"], "error_type": "duplicate_invoice",
                       "error_detail": f"Duplicate of {df.at[i, 'txn_id']}",
                       "vat_at_risk": dup["vat_amount"]})

    if duplicates:
        df = pd.concat([df, pd.DataFrame(duplicates)], ignore_index=True)
    df = df.sort_values(["posting_date", "txn_id"]).reset_index(drop=True)
    df["vat_period"] = [f"{d.year}-Q{(d.month - 1) // 3 + 1}" for d in df["invoice_date"]]
    return df, pd.DataFrame(labels)


def generate(n_rows: int = 2000, error_rate: float = 0.08, seed: int = 42,
             start: date = date(2025, 1, 1), days: int = 365):
    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_GB")
    clean = _clean_ledger(rng, fake, n_rows, start, days)
    return _inject_errors(rng, clean, error_rate)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--rows", type=int, default=2000)
    parser.add_argument("--error-rate", type=float, default=0.08)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out", type=Path, default=Path("data"))
    args = parser.parse_args()

    ledger, truth = generate(args.rows, args.error_rate, args.seed)
    args.out.mkdir(parents=True, exist_ok=True)
    ledger.to_csv(args.out / "ledger.csv", index=False)
    truth.to_csv(args.out / "ground_truth.csv", index=False)

    print(f"Ledger: {len(ledger):,} transactions | Injected errors: {len(truth):,} "
          f"({len(truth) / len(ledger):.1%}) | VAT at risk: £{truth.vat_at_risk.sum():,.2f}")
    print(truth.error_type.value_counts().to_string())


if __name__ == "__main__":
    main()
