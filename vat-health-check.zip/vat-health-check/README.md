# VAT Health-Check: Rules, Anomaly Detection and an Explainable Agent

An open-source pipeline that reviews a UK VAT ledger, flags likely errors, and explains each finding in plain English with a reference to the rule behind it.

> **Status:** work in progress. Steps 1 and 2 are complete (see the roadmap). All data is synthetic. This is a learning and portfolio project, not tax advice.

## The problem

VAT errors are expensive and common: wrong rates, input VAT claimed on blocked items, invalid supplier VAT numbers, duplicate invoices, and misapplied reverse charges. A wrong claim can mean penalties and interest, and an unclaimed one is money left behind.

Most organisations check a small sample by hand because reviewing every transaction is impractical. Errors that fall outside the sample go unnoticed until an audit or an HMRC enquiry.

## The approach

A check on every transaction, built in three layers. Each layer does the job it is best at:

| Layer | Job | Why this technique |
|---|---|---|
| 1. Rules engine | Apply known VAT rules (rates, blocked input tax, VAT number validity, arithmetic) | Deterministic, auditable, and never wrong about a rule it encodes |
| 2. Anomaly detection | Catch unusual transactions the rules do not cover (Isolation Forest) | Finds patterns nobody wrote a rule for |
| 3. Explanation agent | Turn each flag into a plain-English explanation, cite the rule, draft a query to the business | Makes findings usable by a reviewer who is not a data scientist |

**Design principle:** the language model never calculates. Every number comes from deterministic code, and every flag is traceable to a rule or a model score. A human reviewer makes the final decision.

## Roadmap

- [x] **Step 1:** Problem framing, project structure, VAT reference data
- [x] **Step 2:** Synthetic ledger generator with labelled, injected errors
- [ ] **Step 3:** Rules engine (one check per error type)
- [ ] **Step 4:** Evaluation harness (precision, recall, £ at risk)
- [ ] **Step 5:** Anomaly detection layer
- [ ] **Step 6:** Draft VAT return (9 boxes) from the cleaned ledger
- [ ] **Step 7:** Explanation agent with citations and an audit log
- [ ] **Step 8:** Streamlit dashboard

## Quick start

```bash
git clone https://github.com/<your-username>/vat-health-check.git
cd vat-health-check
pip install -r requirements.txt

# Generate a synthetic ledger with hidden errors
python -m vat_health_check.generate_data --rows 2000 --error-rate 0.08 --seed 42

# Run the tests
pytest
```

## The synthetic data

Real ledgers are confidential, so the project generates its own. Because we inject the errors ourselves, we know the ground truth and can measure how well each layer performs.

`data/ledger.csv` is what a checker sees. `data/ground_truth.csv` lists the injected errors and is used for evaluation only.

| Injected error | What goes wrong |
|---|---|
| `wrong_rate` | A standard, reduced or zero rate is applied to the wrong category |
| `invalid_vat_number` | VAT is claimed with a missing supplier VAT number or one that fails its checksum |
| `blocked_input_tax` | Input VAT is claimed on client entertainment, which is not recoverable |
| `duplicate_invoice` | The same invoice is posted twice, sometimes re-keyed in a different format |
| `arithmetic_error` | Gross does not equal net plus VAT, or VAT does not equal net times rate |
| `reverse_charge_misuse` | VAT is charged and claimed on construction work where the domestic reverse charge applies |

The ledger also contains legitimate cases that a naive checker would wrongly flag: unregistered suppliers who correctly charge no VAT, exempt supplies such as insurance and bank charges, and correctly reverse-charged construction work. These test for false positives.

Generated VAT numbers pass the modulus-97 checksum but are random and may coincidentally match a real registration.

## Project layout

```
vat_health_check/
  reference.py       VAT categories, rates and the VAT number checksum
  generate_data.py   synthetic ledger generator
tests/               unit tests
data/                generated ledger and ground truth
```

## Limitations

- Covers a simplified subset of UK VAT rules (standard, reduced, zero, exempt, blocked input tax, domestic reverse charge). It does not cover partial exemption, the flat rate scheme, margin schemes, imports and exports, or cash accounting.
- The VAT number check validates format only. It cannot confirm a registration exists.
- Rates and rules change. Check current HMRC guidance before using any rule on real data.
- Results on synthetic data show the method works. They do not guarantee performance on real ledgers.
