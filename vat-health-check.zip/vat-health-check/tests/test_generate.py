import numpy as np
import pandas as pd

from vat_health_check.generate_data import ERROR_TYPES, generate, make_vat_number
from vat_health_check.reference import CATEGORIES, vat_number_is_valid


def test_generated_vat_numbers_pass_checksum():
    rng = np.random.default_rng(0)
    assert all(vat_number_is_valid(make_vat_number(rng)) for _ in range(500))


def test_bad_vat_numbers_rejected():
    assert not vat_number_is_valid(None)
    assert not vat_number_is_valid("")
    assert not vat_number_is_valid("GB12345")
    assert not vat_number_is_valid("GBABCDEFGHI")


def test_same_seed_gives_identical_output():
    a_ledger, a_truth = generate(500, seed=7)
    b_ledger, b_truth = generate(500, seed=7)
    pd.testing.assert_frame_equal(a_ledger, b_ledger)
    pd.testing.assert_frame_equal(a_truth, b_truth)


def test_every_error_type_is_injected():
    _, truth = generate(2000, seed=1)
    assert set(truth.error_type) == set(ERROR_TYPES)


def test_ground_truth_ids_exist_and_are_unique():
    ledger, truth = generate(1000, seed=3)
    assert truth.txn_id.is_unique
    assert set(truth.txn_id) <= set(ledger.txn_id)


def test_unlabelled_rows_are_arithmetically_clean():
    ledger, truth = generate(2000, seed=5)
    clean = ledger[~ledger.txn_id.isin(truth.txn_id)]
    assert (clean.gross_amount - (clean.net_amount + clean.vat_amount)).abs().max() < 0.011
    assert (clean.vat_amount - (clean.net_amount * clean.vat_rate_applied)).abs().max() < 0.011


def test_unlabelled_rows_have_no_blocked_claims_or_bad_numbers():
    ledger, truth = generate(2000, seed=5)
    clean = ledger[~ledger.txn_id.isin(truth.txn_id)]
    blocked = [n for n, c in CATEGORIES.items() if not c.input_tax_recoverable]
    assert not clean[clean.category.isin(blocked)].input_vat_claimed.any()
    claiming = clean[clean.input_vat_claimed]
    assert claiming.counterparty_vat_no.map(vat_number_is_valid).all()
